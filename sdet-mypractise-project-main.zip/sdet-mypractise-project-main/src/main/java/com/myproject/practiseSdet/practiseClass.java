package com.myproject.practiseSdet;

public class practiseClass {
	
 public int multiply(int a, int b) {
	 return a + b;
 }
 
 public static void main(String[] args) {
	System.out.println("hello this i smy java cicd project");
}


}
